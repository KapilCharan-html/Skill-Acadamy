// SkillAcademy - Main JavaScript

const API = 'http://localhost:5000/api';

// ===== THEME =====
const initTheme = () => {
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  const btn = document.getElementById('themeToggle');
  if (btn) btn.textContent = saved === 'dark' ? '☀️' : '🌙';
};

const toggleTheme = () => {
  const current = document.documentElement.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  const btn = document.getElementById('themeToggle');
  if (btn) btn.textContent = next === 'dark' ? '☀️' : '🌙';
};

// ===== AUTH HELPERS =====
const getToken = () => localStorage.getItem('sa_token');
const getUser = () => {
  const u = localStorage.getItem('sa_user');
  return u ? JSON.parse(u) : null;
};
const setAuth = (token, user) => {
  localStorage.setItem('sa_token', token);
  localStorage.setItem('sa_user', JSON.stringify(user));
};
const clearAuth = () => {
  localStorage.removeItem('sa_token');
  localStorage.removeItem('sa_user');
};
const isLoggedIn = () => !!getToken();
const isAdmin = () => { const u = getUser(); return u && u.role === 'admin'; };

// ===== API REQUEST =====
const request = async (url, options = {}) => {
  const token = getToken();
  const headers = { 'Content-Type': 'application/json', ...options.headers };
  if (token) headers['Authorization'] = `Bearer ${token}`;
  const resp = await fetch(`${API}${url}`, { ...options, headers });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.message || 'Request failed');
  return data;
};

// ===== TOAST =====
const toast = (message, type = 'info') => {
  let container = document.getElementById('toastContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toastContainer';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const t = document.createElement('div');
  t.className = `toast toast-${type}`;
  t.innerHTML = `<span>${icons[type]}</span><span>${message}</span>`;
  container.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; t.style.transform = 'translateX(100px)'; setTimeout(() => t.remove(), 300); }, 3500);
};

// ===== NAV STATE =====
const updateNavState = () => {
  const user = getUser();
  const loginBtns = document.querySelectorAll('.nav-login');
  const signupBtns = document.querySelectorAll('.nav-signup');
  const dashBtns = document.querySelectorAll('.nav-dashboard');
  const logoutBtns = document.querySelectorAll('.nav-logout');
  const userMenus = document.querySelectorAll('.nav-user-menu');

  if (isLoggedIn() && user) {
    loginBtns.forEach(b => b.style.display = 'none');
    signupBtns.forEach(b => b.style.display = 'none');
    dashBtns.forEach(b => { b.style.display = ''; b.href = user.role === 'admin' ? '/dashboard/adminDashboard.html' : '/dashboard/userDashboard.html'; });
    logoutBtns.forEach(b => b.style.display = '');
    userMenus.forEach(m => { m.style.display = ''; m.textContent = user.name.split(' ')[0]; });
  } else {
    loginBtns.forEach(b => b.style.display = '');
    signupBtns.forEach(b => b.style.display = '');
    dashBtns.forEach(b => b.style.display = 'none');
    logoutBtns.forEach(b => b.style.display = 'none');
    userMenus.forEach(m => m.style.display = 'none');
  }
};

// ===== LOGOUT =====
const logout = () => {
  clearAuth();
  toast('Logged out successfully', 'info');
  setTimeout(() => window.location.href = '/', 800);
};

// ===== COUNTER ANIMATION =====
const animateCounter = (el, target, duration = 2000) => {
  let start = 0;
  const increment = target / (duration / 16);
  const timer = setInterval(() => {
    start += increment;
    if (start >= target) { el.textContent = formatNumber(target); clearInterval(timer); }
    else el.textContent = formatNumber(Math.floor(start));
  }, 16);
};

const formatNumber = (num) => {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M+';
  if (num >= 1000) return (num / 1000).toFixed(0) + 'K+';
  return num.toString();
};

// ===== AOS (Scroll Animations) =====
const initAOS = () => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('aos-animate');
        // Counter animation
        if (entry.target.classList.contains('counter')) {
          const target = parseInt(entry.target.dataset.target);
          animateCounter(entry.target, target);
        }
      }
    });
  }, { threshold: 0.15, rootMargin: '0px 0px -40px 0px' });

  document.querySelectorAll('[data-aos], .counter').forEach(el => observer.observe(el));
};

// ===== COURSE CARD RENDERER =====
const getCategoryBadgeClass = (cat) => {
  const map = {
    'Web Development': 'badge-web',
    'Machine Learning': 'badge-ml',
    'Design': 'badge-design',
    'Mobile Development': 'badge-mobile',
    'Data Science': 'badge-data',
    'Marketing': 'badge-marketing',
    'Business': 'badge-other',
    'Photography': 'badge-other',
    'Music': 'badge-other',
    'Other': 'badge-other'
  };
  return map[cat] || 'badge-other';
};

const getCategoryEmoji = (cat) => {
  const map = {
    'Web Development': '💻', 'Machine Learning': '🤖', 'Design': '🎨',
    'Mobile Development': '📱', 'Data Science': '📊', 'Marketing': '📣',
    'Business': '💼', 'Photography': '📷', 'Music': '🎵', 'Other': '📚'
  };
  return map[cat] || '📚';
};

const renderStars = (rating) => {
  const full = Math.floor(rating);
  const half = rating % 1 >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  return '★'.repeat(full) + (half ? '½' : '') + '☆'.repeat(empty);
};

const renderCourseCard = (course, showEnroll = true) => {
  const badgeClass = getCategoryBadgeClass(course.category);
  const emoji = getCategoryEmoji(course.category);
  const thumbContent = course.thumbnail
    ? `<img src="${course.thumbnail}" alt="${course.title}" onerror="this.parentElement.innerHTML='<span style=font-size:60px>${emoji}</span>'">`
    : `<span style="font-size:60px">${emoji}</span>`;

  return `
    <div class="course-card" onclick="window.location.href='/courses.html?id=${course._id}'">
      <div class="course-card-thumb">
        ${thumbContent}
        <div class="thumb-overlay"></div>
      </div>
      <div class="course-card-body">
        <span class="course-badge ${badgeClass}">${course.category}</span>
        <h3 class="course-card-title">${course.title}</h3>
        <p class="course-card-instructor">👤 ${course.instructor}</p>
        <div class="course-rating">
          <span class="rating-stars">${renderStars(course.rating)}</span>
          <span class="rating-num">${course.rating.toFixed(1)}</span>
          <span class="rating-count">(${formatNumber(course.totalRatings || 0)})</span>
        </div>
        <div class="course-meta">
          <span>⏱️ ${course.duration || 'N/A'}</span>
          <span>📚 ${course.totalLessons || 0} lessons</span>
          <span>📊 ${course.level}</span>
        </div>
        <div class="course-card-footer">
          ${course.price === 0 ? '<span class="course-price-free">FREE</span>' : `<span class="course-price">$${course.price}</span>`}
          ${showEnroll ? `<button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); enrollCourse('${course._id}')">Enroll Now</button>` : ''}
        </div>
      </div>
    </div>
  `;
};

// ===== ENROLL =====
const enrollCourse = async (courseId) => {
  if (!isLoggedIn()) {
    toast('Please login to enroll', 'warning');
    setTimeout(() => window.location.href = '/login.html', 1000);
    return;
  }
  try {
    await request('/enroll', { method: 'POST', body: JSON.stringify({ courseId }) });
    toast('Successfully enrolled! 🎉', 'success');
  } catch (err) {
    toast(err.message, 'error');
  }
};

// ===== MOBILE NAV =====
const initMobileNav = () => {
  const hamburger = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  if (hamburger && mobileMenu) {
    hamburger.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }

  const sidebarToggle = document.getElementById('sidebarToggle');
  const sidebar = document.getElementById('sidebar');
  if (sidebarToggle && sidebar) {
    sidebarToggle.addEventListener('click', () => sidebar.classList.toggle('open'));
  }
};

// ===== PROTECT ROUTE =====
const requireAuth = (redirectTo = '/login.html') => {
  if (!isLoggedIn()) {
    window.location.href = redirectTo;
    return false;
  }
  return true;
};

const requireAdmin = () => {
  if (!isLoggedIn() || !isAdmin()) {
    window.location.href = '/login.html';
    return false;
  }
  return true;
};

// ===== FORMAT DATE =====
const formatDate = (dateStr) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
};

const timeAgo = (dateStr) => {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
};

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  updateNavState();
  initAOS();
  initMobileNav();

  // Theme toggle
  document.querySelectorAll('#themeToggle, .theme-toggle').forEach(btn => {
    btn.addEventListener('click', toggleTheme);
  });

  // Logout
  document.querySelectorAll('.nav-logout, #logoutBtn').forEach(btn => {
    btn.addEventListener('click', (e) => { e.preventDefault(); logout(); });
  });
});
