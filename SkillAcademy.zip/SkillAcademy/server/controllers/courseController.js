const Course = require('../models/Course');
const Enrollment = require('../models/Enrollment');

// @desc    Get all courses
// @route   GET /api/courses
// @access  Public
const getCourses = async (req, res) => {
  try {
    const { search, category, level, minPrice, maxPrice, sort, page = 1, limit = 12 } = req.query;
    const query = { isPublished: true };

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { instructor: { $regex: search, $options: 'i' } }
      ];
    }
    if (category && category !== 'All') query.category = category;
    if (level && level !== 'All') query.level = level;
    if (minPrice !== undefined || maxPrice !== undefined) {
      query.price = {};
      if (minPrice !== undefined) query.price.$gte = Number(minPrice);
      if (maxPrice !== undefined) query.price.$lte = Number(maxPrice);
    }

    let sortObj = { createdAt: -1 };
    if (sort === 'price_asc') sortObj = { price: 1 };
    else if (sort === 'price_desc') sortObj = { price: -1 };
    else if (sort === 'rating') sortObj = { rating: -1 };
    else if (sort === 'popular') sortObj = { enrolledCount: -1 };

    const skip = (Number(page) - 1) * Number(limit);
    const courses = await Course.find(query).sort(sortObj).skip(skip).limit(Number(limit));
    const total = await Course.countDocuments(query);

    res.status(200).json({
      success: true,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit)),
      courses
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error fetching courses.' });
  }
};

// @desc    Get featured courses
// @route   GET /api/courses/featured
// @access  Public
const getFeaturedCourses = async (req, res) => {
  try {
    const courses = await Course.find({ isFeatured: true, isPublished: true }).limit(6);
    res.status(200).json({ success: true, courses });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// @desc    Get single course
// @route   GET /api/courses/:id
// @access  Public
const getCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ success: false, message: 'Course not found.' });
    res.status(200).json({ success: true, course });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// @desc    Create new course
// @route   POST /api/courses
// @access  Admin
const createCourse = async (req, res) => {
  try {
    const courseData = { ...req.body, instructorId: req.user._id };
    const course = await Course.create(courseData);
    res.status(201).json({ success: true, message: 'Course created!', course });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(e => e.message);
      return res.status(400).json({ success: false, message: messages.join('. ') });
    }
    res.status(500).json({ success: false, message: 'Server error creating course.' });
  }
};

// @desc    Update course
// @route   PUT /api/courses/:id
// @access  Admin
const updateCourse = async (req, res) => {
  try {
    const course = await Course.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!course) return res.status(404).json({ success: false, message: 'Course not found.' });
    res.status(200).json({ success: true, message: 'Course updated!', course });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error updating course.' });
  }
};

// @desc    Delete course
// @route   DELETE /api/courses/:id
// @access  Admin
const deleteCourse = async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ success: false, message: 'Course not found.' });
    await course.deleteOne();
    await Enrollment.deleteMany({ course: req.params.id });
    res.status(200).json({ success: true, message: 'Course deleted.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error deleting course.' });
  }
};

// @desc    Get admin stats
// @route   GET /api/courses/stats
// @access  Admin
const getStats = async (req, res) => {
  try {
    const User = require('../models/User');
    const totalUsers = await User.countDocuments({ role: 'user' });
    const totalCourses = await Course.countDocuments();
    const totalEnrollments = await Enrollment.countDocuments();
    const completedEnrollments = await Enrollment.countDocuments({ isCompleted: true });

    // Monthly user growth (last 6 months)
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    const monthlyUsers = await User.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      { $group: { _id: { month: { $month: '$createdAt' }, year: { $year: '$createdAt' } }, count: { $sum: 1 } } },
      { $sort: { '_id.year': 1, '_id.month': 1 } }
    ]);

    // Top categories
    const topCategories = await Course.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 }, enrollments: { $sum: '$enrolledCount' } } },
      { $sort: { enrollments: -1 } },
      { $limit: 6 }
    ]);

    // Recent enrollments
    const recentEnrollments = await Enrollment.find({})
      .populate('user', 'name email')
      .populate('course', 'title')
      .sort({ enrolledAt: -1 })
      .limit(10);

    res.status(200).json({
      success: true,
      stats: {
        totalUsers,
        totalCourses,
        totalEnrollments,
        completedEnrollments,
        monthlyUsers,
        topCategories,
        recentEnrollments
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error fetching stats.' });
  }
};

module.exports = { getCourses, getFeaturedCourses, getCourse, createCourse, updateCourse, deleteCourse, getStats };
