require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const connectDB = require('./config/db');
const User = require('./models/User');
const Course = require('./models/Course');
const Enrollment = require('./models/Enrollment');

const seedData = async () => {
  await connectDB();

  // Clear existing data
  await User.deleteMany({});
  await Course.deleteMany({});
  await Enrollment.deleteMany({});
  console.log('🗑️  Cleared existing data');

  // Create admin user
  const admin = await User.create({
    name: 'Admin User',
    email: 'admin@skillacademy.com',
    password: 'admin123',
    role: 'admin',
    bio: 'Platform administrator'
  });

  // Create sample users
  const users = await User.create([
    { name: 'Alice Johnson', email: 'alice@example.com', password: 'password123', bio: 'Full stack developer' },
    { name: 'Bob Smith', email: 'bob@example.com', password: 'password123', bio: 'Data scientist' },
    { name: 'Carol White', email: 'carol@example.com', password: 'password123', bio: 'UI/UX designer' },
    { name: 'David Brown', email: 'david@example.com', password: 'password123', bio: 'Mobile developer' },
    { name: 'Eva Martinez', email: 'eva@example.com', password: 'password123', bio: 'Machine learning engineer' }
  ]);

  // Create courses
  const courses = await Course.create([
    {
      title: 'Complete Web Development Bootcamp 2024',
      description: 'Master HTML, CSS, JavaScript, React, Node.js, MongoDB and more. Build real-world projects and become a full-stack developer from scratch.',
      price: 89.99,
      instructor: 'Dr. Angela Yu',
      category: 'Web Development',
      level: 'Beginner',
      duration: '65 hours',
      rating: 4.8,
      totalRatings: 342891,
      enrolledCount: 850000,
      isFeatured: true,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/web-development-programmer-engineering-coding-website-augmented-reality-interface-screens-developer-project-engineer-programming-software-application-design-cartoon-illustration_107791-3863.jpg',
      whatYouLearn: ['Build 16+ web projects', 'Master HTML5 & CSS3', 'JavaScript ES6+', 'React.js & Node.js', 'MongoDB & SQL'],
      requirements: ['No programming experience needed', 'A computer with internet access'],
      tags: ['html', 'css', 'javascript', 'react', 'nodejs'],
      lessons: [
        { title: 'Introduction to Web Development', duration: '15 min' },
        { title: 'HTML Basics', duration: '45 min' },
        { title: 'CSS Styling', duration: '60 min' },
        { title: 'JavaScript Fundamentals', duration: '90 min' },
        { title: 'Responsive Design', duration: '45 min' },
        { title: 'Introduction to React', duration: '120 min' },
        { title: 'Node.js Backend', duration: '90 min' },
        { title: 'MongoDB Database', duration: '60 min' }
      ]
    },
    {
      title: 'Machine Learning A-Z: AI, Python & R',
      description: 'Learn to create Machine Learning Algorithms in Python and R from two Data Science experts. Includes ChatGPT bonus section.',
      price: 94.99,
      instructor: 'Kirill Eremenko',
      category: 'Machine Learning',
      level: 'Intermediate',
      duration: '44 hours',
      rating: 4.5,
      totalRatings: 186741,
      enrolledCount: 1000000,
      isFeatured: true,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/gradient-machine-learning-infographic_23-2149191741.jpg',
      whatYouLearn: ['Master Machine Learning', 'Make accurate predictions', 'Powerful analysis', 'Use Python & R'],
      requirements: ['High school math level', 'Basic Python knowledge'],
      tags: ['python', 'machine learning', 'ai', 'data science'],
      lessons: [
        { title: 'What is Machine Learning?', duration: '20 min' },
        { title: 'Data Preprocessing', duration: '60 min' },
        { title: 'Regression Models', duration: '90 min' },
        { title: 'Classification', duration: '75 min' },
        { title: 'Clustering', duration: '60 min' },
        { title: 'Neural Networks', duration: '120 min' }
      ]
    },
    {
      title: 'UI/UX Design Masterclass',
      description: 'Complete guide to User Interface and Experience design. Learn Figma, design principles, prototyping, and how to create stunning digital products.',
      price: 74.99,
      instructor: 'Gary Simon',
      category: 'Design',
      level: 'Beginner',
      duration: '32 hours',
      rating: 4.7,
      totalRatings: 92000,
      enrolledCount: 320000,
      isFeatured: true,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/gradient-ui-ux-background_23-2149052117.jpg',
      whatYouLearn: ['Design beautiful interfaces', 'Master Figma', 'Create prototypes', 'UX research methods'],
      requirements: ['No design experience needed', 'Figma (free tool)'],
      tags: ['ui', 'ux', 'figma', 'design'],
      lessons: [
        { title: 'Design Principles', duration: '30 min' },
        { title: 'Color Theory', duration: '45 min' },
        { title: 'Typography', duration: '40 min' },
        { title: 'Figma Basics', duration: '90 min' },
        { title: 'Wireframing', duration: '60 min' },
        { title: 'Prototyping', duration: '75 min' }
      ]
    },
    {
      title: 'iOS & Swift - The Complete iOS App Development',
      description: 'Learn iOS app development with Swift 5.9. Build 16 real iOS apps and master Xcode, UIKit, SwiftUI and more.',
      price: 84.99,
      instructor: 'Dr. Angela Yu',
      category: 'Mobile Development',
      level: 'Beginner',
      duration: '55 hours',
      rating: 4.8,
      totalRatings: 78000,
      enrolledCount: 210000,
      isFeatured: true,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/app-development-banner_33099-1720.jpg',
      whatYouLearn: ['Build iOS apps', 'Master Swift 5.9', 'SwiftUI', 'App Store submission'],
      requirements: ['Mac computer required', 'No programming experience'],
      tags: ['ios', 'swift', 'mobile', 'apple'],
      lessons: [
        { title: 'Swift Basics', duration: '60 min' },
        { title: 'Xcode Walkthrough', duration: '45 min' },
        { title: 'UI Components', duration: '90 min' },
        { title: 'SwiftUI Introduction', duration: '75 min' },
        { title: 'Data Persistence', duration: '60 min' }
      ]
    },
    {
      title: 'Python for Data Science and Machine Learning',
      description: 'Learn how to use NumPy, Pandas, Seaborn, Matplotlib, Plotly, Scikit-Learn, and more. Complete Python data science course.',
      price: 79.99,
      instructor: 'Jose Portilla',
      category: 'Data Science',
      level: 'Intermediate',
      duration: '25 hours',
      rating: 4.6,
      totalRatings: 134000,
      enrolledCount: 450000,
      isFeatured: false,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/data-analysis-concept-illustration_114360-1554.jpg',
      whatYouLearn: ['Python for data science', 'Machine learning algorithms', 'Data visualization', 'Statistical analysis'],
      requirements: ['Basic Python knowledge', 'Understanding of math'],
      tags: ['python', 'pandas', 'numpy', 'data science'],
      lessons: [
        { title: 'Python Refresher', duration: '60 min' },
        { title: 'NumPy Arrays', duration: '45 min' },
        { title: 'Pandas DataFrames', duration: '90 min' },
        { title: 'Data Visualization', duration: '75 min' },
        { title: 'ML with Scikit-Learn', duration: '120 min' }
      ]
    },
    {
      title: 'Digital Marketing Masterclass 2024',
      description: 'Master digital marketing: SEO, social media, PPC, content marketing, email marketing and analytics. Grow any business online.',
      price: 69.99,
      instructor: 'Brad Merrill',
      category: 'Marketing',
      level: 'Beginner',
      duration: '30 hours',
      rating: 4.4,
      totalRatings: 56000,
      enrolledCount: 180000,
      isFeatured: false,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/digital-marketing-concept-illustration_114360-1497.jpg',
      whatYouLearn: ['SEO mastery', 'Social media marketing', 'Google Ads', 'Email marketing'],
      requirements: ['No marketing experience needed'],
      tags: ['marketing', 'seo', 'social media', 'digital'],
      lessons: [
        { title: 'Digital Marketing Overview', duration: '30 min' },
        { title: 'SEO Fundamentals', duration: '90 min' },
        { title: 'Social Media Strategy', duration: '75 min' },
        { title: 'Google Analytics', duration: '60 min' },
        { title: 'Email Campaigns', duration: '45 min' }
      ]
    },
    {
      title: 'React - The Complete Guide 2024',
      description: 'Dive into React.js, Hooks, Redux, React Router, Next.js, and more. Build amazing web applications.',
      price: 84.99,
      instructor: 'Maximilian Schwarzmüller',
      category: 'Web Development',
      level: 'Intermediate',
      duration: '68 hours',
      rating: 4.8,
      totalRatings: 212000,
      enrolledCount: 750000,
      isFeatured: true,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/react-native-mobile-development_23-2148682136.jpg',
      whatYouLearn: ['React hooks', 'Redux state management', 'Next.js', 'Testing React apps'],
      requirements: ['JavaScript knowledge required', 'Basic HTML/CSS'],
      tags: ['react', 'redux', 'javascript', 'nextjs'],
      lessons: [
        { title: 'React Basics', duration: '90 min' },
        { title: 'Components & Props', duration: '60 min' },
        { title: 'State & Hooks', duration: '120 min' },
        { title: 'Redux', duration: '90 min' },
        { title: 'Next.js', duration: '75 min' }
      ]
    },
    {
      title: 'The Complete Photography Masterclass',
      description: 'Master photography from beginner to professional. Learn composition, lighting, editing in Lightroom and Photoshop.',
      price: 59.99,
      instructor: 'Phil Ebiner',
      category: 'Photography',
      level: 'Beginner',
      duration: '20 hours',
      rating: 4.5,
      totalRatings: 43000,
      enrolledCount: 120000,
      isFeatured: false,
      isPublished: true,
      thumbnail: 'https://img.freepik.com/free-vector/photography-concept-illustration_114360-2201.jpg',
      whatYouLearn: ['Camera settings mastery', 'Composition techniques', 'Lightroom editing', 'Portrait photography'],
      requirements: ['Any camera (DSLR or smartphone)', 'Willingness to practice'],
      tags: ['photography', 'lightroom', 'photoshop', 'editing'],
      lessons: [
        { title: 'Camera Basics', duration: '45 min' },
        { title: 'Exposure Triangle', duration: '60 min' },
        { title: 'Composition Rules', duration: '50 min' },
        { title: 'Lightroom Editing', duration: '90 min' }
      ]
    }
  ]);

  // Create sample enrollments
  const enrollments = [];
  for (let i = 0; i < users.length; i++) {
    const numCourses = Math.floor(Math.random() * 3) + 1;
    const shuffled = [...courses].sort(() => Math.random() - 0.5);
    for (let j = 0; j < numCourses; j++) {
      enrollments.push({
        user: users[i]._id,
        course: shuffled[j]._id,
        progress: Math.floor(Math.random() * 100),
        enrolledAt: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000)
      });
    }
  }
  await Enrollment.insertMany(enrollments);

  console.log('✅ Seed data created successfully!');
  console.log(`👤 Admin: admin@skillacademy.com / admin123`);
  console.log(`👥 Users: alice@example.com / password123`);
  console.log(`📚 ${courses.length} courses created`);
  console.log(`📝 ${enrollments.length} enrollments created`);

  mongoose.connection.close();
};

seedData().catch(console.error);
