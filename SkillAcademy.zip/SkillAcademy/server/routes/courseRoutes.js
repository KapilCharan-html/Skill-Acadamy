const express = require('express');
const router = express.Router();
const { getCourses, getFeaturedCourses, getCourse, createCourse, updateCourse, deleteCourse, getStats } = require('../controllers/courseController');
const { protect, adminOnly } = require('../middleware/authMiddleware');

router.get('/stats', protect, adminOnly, getStats);
router.get('/featured', getFeaturedCourses);
router.get('/', getCourses);
router.get('/:id', getCourse);
router.post('/', protect, adminOnly, createCourse);
router.put('/:id', protect, adminOnly, updateCourse);
router.delete('/:id', protect, adminOnly, deleteCourse);

module.exports = router;
