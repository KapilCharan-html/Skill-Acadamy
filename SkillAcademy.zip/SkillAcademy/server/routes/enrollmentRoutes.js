const express = require('express');
const router = express.Router();
const Enrollment = require('../models/Enrollment');
const Course = require('../models/Course');
const { protect, adminOnly } = require('../middleware/authMiddleware');

// @desc    Enroll in a course
// @route   POST /api/enroll
// @access  Private
router.post('/', protect, async (req, res) => {
  try {
    const { courseId } = req.body;
    if (!courseId) return res.status(400).json({ success: false, message: 'Course ID is required.' });

    const course = await Course.findById(courseId);
    if (!course) return res.status(404).json({ success: false, message: 'Course not found.' });

    const existingEnrollment = await Enrollment.findOne({ user: req.user._id, course: courseId });
    if (existingEnrollment) return res.status(400).json({ success: false, message: 'Already enrolled in this course.' });

    const enrollment = await Enrollment.create({ user: req.user._id, course: courseId });
    await Course.findByIdAndUpdate(courseId, { $inc: { enrolledCount: 1 } });

    res.status(201).json({ success: true, message: 'Successfully enrolled!', enrollment });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error enrolling.' });
  }
});

// @desc    Get current user's enrollments
// @route   GET /api/enrollments
// @access  Private
router.get('/', protect, async (req, res) => {
  try {
    const enrollments = await Enrollment.find({ user: req.user._id })
      .populate('course', 'title description thumbnail instructor category level duration totalLessons rating price')
      .sort({ enrolledAt: -1 });
    res.status(200).json({ success: true, enrollments });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @desc    Get all enrollments (admin)
// @route   GET /api/enrollments/all
// @access  Admin
router.get('/all', protect, adminOnly, async (req, res) => {
  try {
    const enrollments = await Enrollment.find({})
      .populate('user', 'name email')
      .populate('course', 'title')
      .sort({ enrolledAt: -1 })
      .limit(50);
    res.status(200).json({ success: true, enrollments });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @desc    Update lesson progress
// @route   PUT /api/enrollments/:courseId/progress
// @access  Private
router.put('/:courseId/progress', protect, async (req, res) => {
  try {
    const { lessonId, progress } = req.body;
    const enrollment = await Enrollment.findOne({ user: req.user._id, course: req.params.courseId });
    if (!enrollment) return res.status(404).json({ success: false, message: 'Enrollment not found.' });

    if (lessonId) {
      const alreadyCompleted = enrollment.completedLessons.some(l => l.lessonId?.toString() === lessonId);
      if (!alreadyCompleted) {
        enrollment.completedLessons.push({ lessonId });
      }
    }
    if (progress !== undefined) enrollment.progress = progress;
    enrollment.lastAccessedAt = new Date();
    await enrollment.save();

    res.status(200).json({ success: true, message: 'Progress updated!', enrollment });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// @desc    Check enrollment status
// @route   GET /api/enrollments/check/:courseId
// @access  Private
router.get('/check/:courseId', protect, async (req, res) => {
  try {
    const enrollment = await Enrollment.findOne({ user: req.user._id, course: req.params.courseId });
    res.status(200).json({ success: true, enrolled: !!enrollment, enrollment });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
